package timaxa007.killed_whom;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;

@Mod(modid = KilledWhomMod.MODID, name = KilledWhomMod.NAME, version = KilledWhomMod.VERSION)
public class KilledWhomMod {

	public static final String
	MODID = "killed_whom",
	NAME = "Killed Whom Mod",
	VERSION = "1.0";

	@Mod.Instance(MODID)
	public static KilledWhomMod instance;

	@SideOnly(Side.CLIENT)
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		Events e = new Events();
		Configuration config = new Configuration(event.getSuggestedConfigurationFile());
		config.load();
		String category = "gui";
		e.direction = (byte)config.get("gui", "direction", e.direction,
				"0 - left-top,		1 - center-top,		2 - right-top, \n" +
				"3 - left-center,	4 - center-center,	5 - right-center, \n" +
				"6 - left-botton,	7 - center-botton,	8 - right-botton.").getInt();
		config.save();
		MinecraftForge.EVENT_BUS.register(e);
		FMLCommonHandler.instance().bus().register(e);
	}

}

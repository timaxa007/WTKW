package timaxa007.killed_whom;

import java.util.ArrayList;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EntityDamageSource;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

@SideOnly(Side.CLIENT)
public class Events {

	private static final Minecraft mc = Minecraft.getMinecraft();
	public static byte direction;
	public static int delayShowMax = 60;
	private static ArrayList<WTKW> list = new ArrayList<WTKW>();

	/**Who Than Killed Whom**/
	public static class WTKW {

		public final String who, whom;
		public final ItemStack than;
		public final long time;
		public final int offset;

		public WTKW(String who, ItemStack than, String whom, long time, int offset) {
			this.who = who;
			this.than = than;
			this.whom = whom;
			this.time = time;
			this.offset = offset;
		}

	}

	@SubscribeEvent
	public void drawText(RenderGameOverlayEvent.Post event) {
		int x, y;
		switch(event.type) {
		case ALL:
			GL11.glPushMatrix();
			Minecraft.getMinecraft().getTextureManager().bindTexture(TextureMap.locationItemsTexture);

			x = event.resolution.getScaledWidth() / 2;
			for (int i = list.size() - 1; i >= 0; --i) {
				WTKW wtkw = list.get(i);
				if (wtkw.than == null) continue;
				y = ((i) * 16) + 10;
				mc.ingameGUI.drawTexturedModelRectFromIcon(x - 9, y - 3, wtkw.than.getIconIndex(), 16, 16);
			}

			GL11.glColor4f(1F, 1F, 1F, 1F);
			GL11.glPopMatrix();
			break;
		case TEXT:
			x = event.resolution.getScaledWidth() / 2;
			for (int i = list.size() - 1; i >= 0; --i) {
				WTKW wtkw = list.get(i);
				float alpha = mc.theWorld.getTotalWorldTime();
				y = ((i) * 16) + 10;
				mc.fontRenderer.drawStringWithShadow(wtkw.who, x - 9 - wtkw.offset, y, 0xFFFFFF);
				mc.fontRenderer.drawStringWithShadow(wtkw.whom, x + 9, y, 0xFFFFFF);
			}
			break;
		default:return;
		}
	}

	@SubscribeEvent
	public void deathWTKW(LivingDeathEvent event) {
		Entity from = event.source.getSourceOfDamage();//Кто убил.
		EntityLivingBase whom = event.entityLiving;//Кого убили.
		if (from instanceof EntityLivingBase && event.source instanceof EntityDamageSource)
			addWTKW(((EntityDamageSource)event.source).getEntity(), ((EntityLivingBase)from).getHeldItem(), whom);
		else if (from instanceof EntityArrow)
			addWTKW((EntityLivingBase)((EntityArrow)from).shootingEntity, new ItemStack(Items.arrow), whom);
		else if (from instanceof EntityThrowable)
			addWTKW(((EntityThrowable)from).getThrower(), null, whom);
		else if (from instanceof EntityFireball)
			addWTKW(((EntityFireball)from).shootingEntity, new ItemStack(Items.fire_charge), whom);
		else
			addWTKW(from, null, whom);
	}

	private static void addWTKW(Entity from, ItemStack than, EntityLivingBase whom) {
		if (from == null) return;
		if (whom == null) return;

		String a = null, b = null;

		if (from instanceof EntityPlayer)
			a = ((EntityPlayer)from).getDisplayName();
		else
			a = from.getCommandSenderName();

		if (whom instanceof EntityPlayer)
			b = ((EntityPlayer)whom).getDisplayName();
		else
			b = whom.getCommandSenderName();

		long time = from.worldObj.getTotalWorldTime() + delayShowMax;
		if (time > Long.MAX_VALUE) time = Long.MAX_VALUE;

		if (a != null && b != null) list.add(new WTKW(a, than, b, time,
				(direction % 3 == 2 ? mc.fontRenderer.getStringWidth(b) : mc.fontRenderer.getStringWidth(a))));
	}

	@SubscribeEvent
	public void tickClient(TickEvent.ClientTickEvent event) {
		if (mc.theWorld == null) return;
		if (list.isEmpty()) return;

		if (mc.theWorld.getTotalWorldTime() == 0) {
			list.clear();
			return;
		}

		for (int i = 0; i < list.size(); ++i) {
			if (mc.theWorld.getTotalWorldTime() >= list.get(i).time) list.remove(i--);
		}
	}

	@SubscribeEvent
	public void firstMessegeOut(ClientDisconnectionFromServerEvent event) {
		list.clear();
		list.trimToSize();
	}

}
